/**
 * 
 */
package vue.swing.partie;

import controleur.PartieController;

/**
 * @author Paul
 * 
 */
public class JPanelPartieView extends PartieView {

	/**
	 * S�mantique : Cr�e un JPanelPartieView
	 * Pr�conditions :
	 * Postconditions :
	 * 
	 * @param controller
	 */
	public JPanelPartieView(PartieController controller) {
		super(controller);
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see vue.swing.partie.PartieView#close()
	 */
	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see vue.swing.partie.PartieView#display()
	 */
	@Override
	public void display() {
		// TODO Auto-generated method stub

	}

}
