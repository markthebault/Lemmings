/**
 * 
 */
package modele.jeu.partie.niveau.lemming.aptitude;

/**
 * @author Paul
 * 
 */

/**
 * S�mantique : Enumeration des types d aptitudes posibles
 * Pr�conditions :
 * Postconditions :
 * 
 */
public enum TypeAptitude {
	CLIMBER, FLOATER, BLOCKER, BOMBER, BUILDER, BASHER, DIGGER, MINER, WALKER
}
