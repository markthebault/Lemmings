package modele.jeu.partie.niveau.carte;

public class CaseDejaPresenteException extends Exception {

	/**
	 * S�mantique : Cr�e un CaseDejaPredenteException
	 * Pr�conditions :
	 * Postconditions :
	 * 
	 * @param message
	 */
	public CaseDejaPresenteException(String message){
		super(message);
	}
}
