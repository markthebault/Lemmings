package modele.jeu.partie.niveau.lemming;

public enum SensDeplacement {
	VERS_GAUCHE, VERS_DROITE, VERS_HAUT, VERS_BAS;
}