/**
 * 
 */
package modele.jeu.partie.niveau.lemming.aptitude;

/**
 * @author Paul
 * 
 */
public class AptitudeInvalideException extends Exception {

	/**
	 * le serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * S�mantique : Cr�e un AptitudeInvalideException
	 * Pr�conditions :
	 * Postconditions :
	 * 
	 * @param arg0
	 */
	public AptitudeInvalideException(String arg0) {
		super(arg0);
	}

}
