package modele.jeu.partie.niveau.carte;

public enum TypePiege {
	LANCE_FLAMME, BROYEUR;
}