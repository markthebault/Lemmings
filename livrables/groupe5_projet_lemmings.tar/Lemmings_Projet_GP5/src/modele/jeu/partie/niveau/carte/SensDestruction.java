package modele.jeu.partie.niveau.carte;

public enum SensDestruction {
	TOUT, VERS_GAUCHE, VERS_DROITE, VERS_BAS, AUCUN;
}